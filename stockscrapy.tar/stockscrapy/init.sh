rm -rf scrapystockinfo.csv
cp tonghuashun_header.csv scrapystockinfo.csv

